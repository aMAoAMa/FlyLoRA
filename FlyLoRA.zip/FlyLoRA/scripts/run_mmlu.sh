#! /bin/bash

cd ..

CUDA_VISIBLE_DEVICES=0 python finetune.py \
         --base_model "/new_disk/models/TinyLlama-1.1B-Chat" \
         --data_path  "/new_disk/datasets/hendrycks/mmlu" \
         --output_dir "/new_disk/models/output_dir" \
         --batch_size 128 \
         --micro_batch_size 16 \
         --num_epochs 1 \
         --learning_rate 3e-4 \
         --cutoff_len 64 \
         --val_set_size 0 \
         --lora_r 32 \
         --lora_alpha 64 \
         --warmup_rates 0.01 \
         --lora_dropout 0.00 \
         --lora_target_modules "q_proj,v_proj,k_proj,o_proj,gate_proj,down_proj,up_proj" \
         --train_on_inputs \
         --group_by_length \
         --add_eos_token \
         --prompt_template_name "alpaca_mmlu" \
         --A_type "sparse" \
         --top_k 8 \
         --bias_u 0.001 \
         --seed 23
         
         
         

CUDA_VISIBLE_DEVICES=0 python evaluate.py \
         --base_model "/new_disk/models/TinyLlama-1.1B-Chat" \
         --lora_weights "/new_disk/models/output_dir" \
         --test_dataset "/new_disk/datasets/hendrycks/mmlu" \
         --batch_size 8 \
         --prompt_template "alpaca_mmlu" \
         --max_new_tokens 128 \
         --save_path "/new_disk/models/output_dir/lora_test_mmlu.json" \
         --seed 23
