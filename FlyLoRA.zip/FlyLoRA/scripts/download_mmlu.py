from datasets import load_dataset
import os

save_path = "/new_disk/datasets/hendrycks/mmlu"
os.makedirs(save_path, exist_ok=True)

# 正确加载MMLU数据集（名称为cais/mmlu，子集all）
dataset = load_dataset(
    "cais/mmlu",
    name="all",  # 必须指定子集，MMLU的核心子集
    cache_dir=save_path
)

dataset.save_to_disk(save_path)
print(f"数据集已成功下载到：{save_path}")
print(f"数据集结构：{dataset}")

